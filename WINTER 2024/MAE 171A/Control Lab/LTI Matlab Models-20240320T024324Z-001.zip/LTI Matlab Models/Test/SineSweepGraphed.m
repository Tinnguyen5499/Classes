clear all;
close all;
clc;
%%

%Data was altered to remove semi-colon
Test1 = importdata('1DOF_TopHold_SineSweep_Trial1.txt');
Test2 = importdata('1DOF_TopHold_SineSweep_Trial2.txt');
Test3 = importdata('1DOF_TopHold_SineSweep_Trial3.txt');
Test4 = importdata('1DOF_TopHold_SineSweep_Trial4.txt');
Test5 = importdata('1DOF_TopHold_SineSweep_Trial5.txt');

X_T1 = Test1.data(:,1);
X_T2 = Test2.data(:,1);
X_T3 = Test3.data(:,1);
X_T4 = Test4.data(:,1);
X_T5 = Test5.data(:,1);

CE_T1 = Test1.data(:,4);
CE_T2 = Test2.data(:,4);
CE_T3 = Test3.data(:,4);
CE_T4 = Test4.data(:,4);
CE_T5 = Test5.data(:,4);

%HEY TIN: they are all the same b/c the sine sweep sent to the motor is the
%same!!!
figure(1)
hold on;
%plot(X_T1,CE_T1)
%plot(X_T2,CE_T2)
%plot(X_T3,CE_T3)
%plot(X_T4,CE_T4)
plot(X_T5,CE_T5)




